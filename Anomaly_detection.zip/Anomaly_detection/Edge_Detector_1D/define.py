class clu:
    def __init__(self):
        self.Leng = '';
        self.Mean = '';
        self.Stdv = '';
        self.state = '';

class diff:
    def __init__(self):

        self.diff_Leng = '';
        self.diff_Mean = '';
        self.diff_Stdv = '';

